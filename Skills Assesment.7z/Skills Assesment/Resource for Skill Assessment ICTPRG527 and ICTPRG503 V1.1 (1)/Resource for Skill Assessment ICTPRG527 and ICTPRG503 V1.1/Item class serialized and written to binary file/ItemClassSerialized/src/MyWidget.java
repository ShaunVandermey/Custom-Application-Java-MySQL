/*
 * Abstract class myWidget this will act as a  
 * template for other user widgets
 */

/**
 *
 * @author srao3
 */
public interface MyWidget {
    public  void setProfitMargin();
}
